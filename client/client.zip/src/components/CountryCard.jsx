import React from "react";
import { Link } from "react-router-dom";
import './CountryCard.css';

export default function CountryCard({ name, region, flag, id }) {
  return (
    <div id="card">
      <Link to={`/countries/${id}`}><h2>{name}</h2></Link>

      <img src={flag} alt="flag not found" width="150px" />
      <h3>{region}</h3>
    </div>
  );
}
