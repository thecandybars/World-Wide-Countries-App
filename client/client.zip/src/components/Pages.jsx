import React from "react";
import './Pages.css'

export default function Pages({ countriesXPage, totalCountries, pages }) {
  const pageNumbers = [];
  const totalPages = Math.ceil(totalCountries / countriesXPage);

  for (let i = 1; i <= totalPages; i++) {
    pageNumbers.push(i);
  }
  return (
    <nav>
      <ul>
        {pageNumbers &&
          pageNumbers.map((pageNumber) => (
            <li key={pageNumber}>
              <a onClick={() => pages(pageNumber)}>{pageNumber}</a>
            </li>
          ))}
      </ul>
    </nav>
  );
}
