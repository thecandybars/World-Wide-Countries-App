import React from "react";
import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { getCountryDetails } from "../actions";
import './CountryDetails.css';

export default function CountryDetails() {
    const dispatch = useDispatch();

    const { id } = useParams();
    const countryDetails = useSelector((state) => state.CountryDetails);

    // Inicialización
    useEffect(() => {
        dispatch(getCountryDetails(id));
    }, [])

    return (
        <div>
            <h2>CountryDetails
                {countryDetails ? { id } : " No ha cargado"}
            </h2>
        </div>
    )
}