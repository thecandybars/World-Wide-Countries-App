import React from "react";
import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getCountries,
  getActivitiesList,
  orderCountries,
  filterCountries,
} from "../actions";
import { Link } from "react-router-dom";
import CountryCard from "./CountryCard.jsx";
import Pages from "./Pages";
import "./Home.css";

export default function Home() {
  const dispatch = useDispatch();

  
  // LOCAL STATES
  const [order, setOrder] = useState(null);
  const [filter, setFilter] = useState({ region:'', activity:'' });
  // const [countries, setCountries] = useState([]);
  
  const countries = useSelector((state) => state.countries);
  const activitiesList = useSelector((state) => state.activitiesList);
  
  // Paginado
  const [currentPage, setCurrentPage] = useState(1);
  const [countriesXPage, setCountriesXPage] = useState(9);
  const lastCountry = currentPage * countriesXPage;
  const firstCountry = lastCountry - countriesXPage;
  const pageCountries = countries.slice(firstCountry, lastCountry);
  const pages = (page) => {
    setCurrentPage(page);
    if (page === 1) setCountriesXPage(9);
    else setCountriesXPage(10);
  };

  useEffect(() => {
    dispatch(orderCountries(order, countries)); // order=id del botón: discrimina la acción
    // dispatch(filterCountries(filter, countries));
  }, [order,filter]);

  function handleReloadDB(e) {
    e.preventDefault();
    dispatch(getCountries());
    dispatch(getActivitiesList());
  }

  function getRegionsList() {
    return countries
      .map((obj) => obj.region) // convierte el obj en arr
      .filter((item, index, arr) => arr.indexOf(item) === index); // filtra repeticiones
  }
  
  function handleOrder(e) {
    setOrder(e.target.id);
  }

  function handleFilter(e) {
    setFilter({...filter, [e.target.name]:e.target.value}); // { region:'Asia', activity:'Cagar' }
  }

  // La barra de botones se podria modularizar
  return (
    <div>
      <Link to="/activity">Crear actividad</Link>
      <h1>Home de Countries</h1>
      <button
        onClick={(e) => {
          handleReloadDB(e);
        }}
      >
        reload DB
      </button>
      <div>
        <div>
          <input
            type="radio"
            id="asc"
            name="order"
            value="ASC"
            onChange={handleOrder}
          />
          <label>Asc</label>
          <input
            type="radio"
            id="des"
            name="order"
            value="DES"
            onChange={handleOrder}
          />
          <label>Des</label>
          <input
            type="radio"
            id="pop"
            name="order"
            value="Pop"
            onChange={handleOrder}
          />
          <label>Pop</label>
        </div>

        <label>Search:</label>
        <input type="text" id="search" name="search"></input>
        <button>Serch</button>

        {/* <select name="region" onChange={handleFilter}>
          {countries ? (
            getRegionsList().map((reg) => {
              return (
                <option id={reg} value={reg} key={reg}>
                  {reg}
                </option>
              );
            })
          ) : (<h2>No hay regiones para mostrar</h2>)
          }
        </select> */}
        <select name="region" onChange={handleFilter}>
          <option id='all' value='all'></option>
          <option id='Asia' value='Asia'>Asia</option>
          <option id='Oceania' value='Oceania'>Oceania</option>
          <option id='Americas' value='Americas'>Americas</option>
          <option id='Europe' value='Europe'>Europe</option>
          <option id='Africa' value='Africa'>Africa</option>
          <option id='Antartic' value='Antartic'>Antartic</option>
        </select>


        <select name="activity" id="">
          {activitiesList &&
            activitiesList.map((act) => {
              return (
                <option value={act} key={act}>
                  {act}
                </option>
              );
            })}
        </select>

        <Pages
          countriesXPage={countriesXPage}
          totalCountries={countries.length}
          pages={pages}
        />

        <div id="countries">
          {pageCountries ? (
            pageCountries.map((country) => {
              return (
                <CountryCard
                  key={country.id}
                  name={country.name}
                  region={country.region}
                  flag={country.flag}
                />
              );
            })
          ) : (
            <h2>No hay paises para mostrar</h2>
          )}
        </div>
      </div>
    </div>
  );
}
