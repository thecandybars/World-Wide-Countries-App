import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Landing from './components/Landing.jsx'
import Home from './components/Home';
import CountryDetails from './components/CountryDetails';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route  path='/' element={<Landing />}></Route>
        <Route path='/home' element={<Home/>} />
        <Route path='/countries/:id' element={<CountryDetails/> } />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
