import axios from 'axios';

//export const GET_COUNTRIES = 'GET_COUNTRIES';

export function getCountries() {
    // Estudiar este uso de dispatch!!!
    return async function (dispatch) {
        const countries = await axios.get('http://localhost:3001/countries');
        return dispatch({
            type: 'GET_COUNTRIES',
            payload: countries.data,
        })
    }
}
export function getCountryDetails(id) {
    return async function (dispatch) {
        const country = await axios.get('http://localhost:3001/countries/'+id);
        return dispatch({
            type: 'GET_COUNTRY_DETAIL',
            payload: country.data,
        })
    }
}
export function getActivitiesList() {
    return async function (dispatch) {
        const activitiesList = await axios.get('http://localhost:3001/activities');
        return dispatch({
            type: 'GET_ACTIVITIES_LIST',
            payload: activitiesList.data,
        })
    }
}

export function getRegionsList(countries) {
    const regions = countries
        .map((obj) => obj.region) // convierte el obj en arr
        .filter((item, index, arr) => arr.indexOf(item) === index); // filtra repeticiones
    return {
        type: 'GET_REGIONS_LIST',
        payload: regions
    }
}

export function filterCountries(filter, countries) {
    const { region, activity } = filter;
    let countriesFilter =[];
    if(region) {
        countriesFilter = countries.filter(country => country.region === region);
    }
    return {
        type: 'FILTER',
        payload: countriesFilter
    }
}

export function orderCountries(order, countries) {
    if (order === 'asc') {
        countries.sort(function (a, b) {
            const A = a.name.toUpperCase();
            const B = b.name.toUpperCase();
            if (A < B) return -1;
            if (A > B) return 1;
            return 0;   // Son iguales
        });
    };
    if (order === 'des') {
        countries.sort(function (a, b) {
            const A = a.name.toUpperCase();
            const B = b.name.toUpperCase();
            if (A < B) return 1;
            if (A > B) return -1;
            return 0;   // Son iguales
        });
    };
    return {
        type: 'ORDER',
        // type: 'GET_COUNTRIES',
        payload: countries
    }
}